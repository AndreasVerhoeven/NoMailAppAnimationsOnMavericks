HOW TO INSTALL?
===============
1) Copy the AveNoAnimationsInMailPlugin.mailbundle  folder to ~/Library/Mail/Bundles/
2) Open Terminal.app
3) run "defaults write com.apple.mail EnableBundles -int 1"  (without the quotes, of course)
4) Restart Mail.app